/*Global Variables*/
/*Demo webservice*/
//var webServiceUrl = "http://202.129.196.131:8085/demo/test_hurdle/webservices/";

/*LiveUrl Webservice*/
var webServiceUrl = "http://202.129.196.131:8085/hurdles/webservices/";

var offset = 0;
var limit = 10;
var remainderOffset = 0;
var remainderLimit = 10;
var parameters;
var showHurdleListFromNoti = 0;
var showReminderListFromNoti = 0;
/* Setting Date */
var arry = new Array();
arry["01"] = "Jan";
arry["02"] = "Feb";
arry["03"] = "Mar";
arry["04"] = "Apr";
arry["05"] = "May";
arry["06"] = "Jun";
arry["07"] = "Jul";
arry["08"] = "Aug";
arry["09"] = "Sep";
arry["10"] = "Oct";
arry["11"] = "Nov";
arry["12"] = "Dec";

var fullDate = new Date();
//    var ISOdate = fullDate.toISOString();
var SplitLocaleStringdate = new Date(fullDate);
var todayDate = SplitLocaleStringdate.getDate();
var month = SplitLocaleStringdate.getMonth();
var monthName = arry[month];
var year = SplitLocaleStringdate.getFullYear();
var webServiceDateFormat = year + "-" + month + "-" + todayDate;
var currentHours = SplitLocaleStringdate.getHours();
var timeMeridian = currentHours >= 12 ? "pm" : "am";
if (currentHours > 12) {
    currentHours = currentHours - 12;
}
var currentMinutes = SplitLocaleStringdate.getMinutes();
var currentSeconds = SplitLocaleStringdate.getSeconds();
//var totalDate = monthName+"-"+todayDate+"-"+year+","+currentHours+":"+currentMinutes+timeMeridian;
var totalDate = monthName + "-" + todayDate + "-" + year;
var webServiceDataConversion = [];
var descriptionArray = [];
var fullDescMsg;
var shortMsg;
var currentActivePage;
var todayDateForSearchPage;
var TodayHurdleCountZero;
var WeeklyHurdleCountZero;
var MonthlyHurdleCountZero;
var TodayReminderCountZero;
var WeeklyReminderCountZero;
var MonthlyReminderCountZero;
var OSPlatform;
var pushNotification;

localStorage.setItem("AKey", "AIzaSyCx9Z0ZpRM2VOov15TfzVRLxzttrIOys8o");
localStorage.setItem("offset", offset);
localStorage.setItem("limit", limit);
localStorage.setItem("remainderoffset", remainderOffset);
localStorage.setItem("remainderlimit", remainderLimit);

/*End of Date*/

/*-- Device Ready --*/
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady() {
    
    
    if (localStorage.getItem("singleSignOn") == "true") {
        changePage("#firstHurdlePg", "slide", false);
    } else {
        localStorage.setItem("singleSignOn", "false");
    }
    
    StatusBar.styleDefault();
    StatusBar.overlaysWebView(false);
    StatusBar.backgroundColorByHexString("#acacac");
    
    $("#viewHurdlePgCloseBtn").hide();
    $("#viewHurdlePgAddCommentBtn").hide();
    
    //Set date to the field
    var now = new Date();
    var day = ("0" + now.getDate()).slice(-2);
    var month = ("0" + (now.getMonth() + 1)).slice(-2);
    todayDateForSearchPage = now.getFullYear() + "-" + (month) + "-" + (day);
    pushNotification = window.plugins.pushNotification;
    PushNotificationRegistration();
}

function PushNotificationRegistration(){
    OSPlatform = device.platform;
    if(OSPlatform == "iOS"){
        pushNotification.register(
                                  tokenHandler,
                                  errorHandler, {
                                  "badge": "true",
                                  "sound": "true",
                                  "alert": "false",
                                  "ecb": "onNotificationAPN"
                                  });
        
    }else if(OSPlatform == "Android" || OSPlatform == "android"){
        pushNotification.register(
                                  successHandler,
                                  errorHandler, {
                                  "senderID": "197775844302", // Project Number
                                  "ecb": "onNotification"
                                  });

        
}
    
}

function tokenHandler(result) {
    
    localStorage.setItem("DevieToken", result);
    //alert("DeviceToken="+result);
}

function successHandler(result) {
    
    //alert("DeviceToken="+result);
    console.log("Result="+result);
}

function errorHandler(error) {

    showAlert(error, "Huddle System");
}

function onNotificationAPN(event){
    //alert(JSON.stringify(event));
    
    if (event.alert) {
        console.log('notification came');
    }
    
    if (event.data) {
        //navigator.notification.alert(event.data);
    }
    
    if (event.sound) {
        // var snd = new Media(event.sound);
        // snd.play();
    }
    
    if (event.badge) {
        //pushNotification.setApplicationIconBadgeNumber(successHandler, errorHandler, event.badge);
    }
    
    if(event.foreground==0)
    {
        if(event.hurdle_id != "0"){
            
            showHurdleListFromNoti = 1;
            
            localStorage.setItem("hurdleId",event.hurdle_id);
            localStorage.setItem("isViewed",event.is_viewed);
            
            if(currentActivePage == "viewHurdlePg"){
                viewHurdleDetails();
            }else{
                changePage("#viewHurdlePg", "slide", "true");
            }

        }else if(event.reminder_id != "0"){
            
            showReminderListFromNoti = 1;
            
            localStorage.setItem("remainderid",event.reminder_id);
            localStorage.setItem("remainderIsViewed",event.is_viewed);
            
            if(currentActivePage == "viewRemainderPg"){
                viewRemainderDetails();
            }else{
             changePage("#viewRemainderPg", "slide", "true");
            }
            
        }else{
            showAlert("Unable to view comment.","Huddle System");
        }
        
    }
    
}

function onNotification(e){
    
    switch (e.event) {
        case 'registered':
            if (e.regid.length > 0) {
                localStorage.setItem("DevieToken", e.regid);
//alert("Android localStorageDeviceToken"+localStorage.getItem("DevieToken"));
            }
            break;
        case 'message':
            if(e.foreground){
                console.log("foreground");
            }else{
                console.log("background");
                if(e.payload.hurdle_id != "0"){
                    
                    showHurdleListFromNoti = 1;
                    localStorage.setItem("hurdleId",e.payload.hurdle_id);
                    localStorage.setItem("isViewed",e.payload.is_viewed);
                    
                    if(currentActivePage == "viewHurdlePg"){
                       viewHurdleDetails(); 
                    }else{
                    changePage("#viewHurdlePg", "slide", "true");
                    }
                    
                }else if(e.payload.reminder_id != "0"){
                    
                    showReminderListFromNoti = 1;
                    localStorage.setItem("remainderid",e.payload.reminder_id);
                    localStorage.setItem("remainderIsViewed",e.payload.is_viewed);
                    
                    if(currentActivePage == "viewRemainderPg"){
                        viewRemainderDetails();
                    }else{
                        changePage("#viewRemainderPg", "slide", "true");
                    }
                    
                }else{
                    showAlert("Unable to view comment.","Huddle System");
                }
            }
            break;
        case 'error':
            showAlert("Error  In PushNotification", "Huddle System");
            break;
            
        default:
        break;
            
    }
    
}

//document.addEventListener("resume", HurdleAndReminderCount, false);

function HurdleAndReminderCount(){
    
    if((localStorage.getItem("isLoggedOut")=="No")&&(currentActivePage!="loginPg")){
//    changePage("#firstHurdlePg", "slide", "true");
        
        $.mobile.changePage("#firstHurdlePg", {
                            transition: "slide",
                            reverse: "true"
                            });
    if(currentActivePage=="firstHurdlePg"){
        getHurdleCount();
    }
    }else{
        console.log("loggedout");
    }
    }


/* To disable back button in android*/

document.addEventListener("backbutton", onBackKeyDown, false);

function onBackKeyDown(e) {
    e.preventDefault();
}

/*-- pagecontainershow --*/

$(document).on("pagecontainershow", function(event, ui) {
               
               var activePage = $.mobile.pageContainer.pagecontainer("getActivePage");
               
               activePageName = activePage.attr('id');
               
               switch (activePage.attr('id')) {
               case 'loginPg':
               loginPageFunction();
               break;
               case 'firstHurdlePg':
               getHurdleCount();
               break;
               case 'filterHurdlePg':
               listHurdleWebService(localStorage.getItem("offset"), localStorage.getItem("limit"), localStorage.getItem("todayhurdle"));
               break;
               case 'viewHurdlePg':
               viewHurdleDetails();
               break;
               case 'searchHurdlePg':
               loadSearchPgSelectBoxes();
               break;
               case 'closureHurdlePg':
               loadClosureHurdleDetails();
               break;
               case 'filterRemainderPg':
               listRemainderWebService(localStorage.getItem("remainderoffset"), localStorage.getItem("remainderlimit"), localStorage.getItem("todayremainder"));
               break;
               case 'viewRemainderPg':
               viewRemainderDetails();
               break;
               case 'closureRemainderPg':
               loadClosureRemainderDetails();
               break;
               case 'searchRemainderPg':
               loadRemainderSearchPgSelectBoxes();
               break;
               case 'forgotPasswordPg':
               forgotPasswordPgFormReset();
               break;
               default:
               break;
               }
               });



/*-- pagecontainershow End --*/

/*-- Document Ready Start --*/
//$(document).ready(function(){
//
//                  $("#descriptionContent").slideUp("slow");
//
//
//                  });

/*-- Document Ready End --*/

/*Exception Handling Block*/
function errorHandling(originalCode) {
    try {
        originalCode();
    } catch (err) {
        alert(err.message);
    }
}


/*Show App Loading Image From Respective Function*/
function Apploadingicon() {
    
    $("body").append("<div class='modalWindow'/>");
    $("body").bind("touchmove", function(e){e.preventDefault()});
    $.mobile.loading("show", {
                     text: "Loading...",
                     textVisible: true,
                     theme: "b",
                     html: ""
                     });
}

/*Hide App Loading Image From Respective Function*/
function hideLoadingIcon() {
    
    $("body").unbind("touchmove");
    $(".modalWindow").remove();
    $.mobile.loading("hide");
}

/*Check NetConnection Before calling Web Service*/

function checkConnection() {
    
    var networkState = navigator.connection.type;
    var states = {};
    states[Connection.UNKNOWN] = 'Unknown connection';
    states[Connection.ETHERNET] = 'Ethernet connection';
    states[Connection.WIFI] = 'WiFi connection';
    states[Connection.CELL_2G] = 'Cell 2G connection';
    states[Connection.CELL_3G] = 'Cell 3G connection';
    states[Connection.CELL_4G] = 'Cell 4G connection';
    states[Connection.NONE] = 'No network connection';
    if (states[networkState] == 'No network connection') {
        return false;
    } else {
        return true;
    }
}


/*Show alert Box Using From Respective Function*/

function showAlert(alertmessage, title, callBack_func) {
    if (callBack_func) {
        navigator.notification.alert(alertmessage, callBack_func, title, "OK");
    } else {
        navigator.notification.alert(alertmessage, false, title, "OK");
    }
}

/* webService Function */

function hurdleSystemWebService(requestType, methodName, param, callBack) {
    
    errorHandling(function() {
                  Apploadingicon();
                  if (checkConnection()) {
                  $.ajax({
                         type: "" + requestType + "",
                         url: webServiceUrl + "" + methodName + "",
                         data: param,
                         success: function(msg) {
                         callBack(msg);
                         },
                         error: function(xhr) {
                         console.log("sdf" + JSON.stringify(xhr));
                         showAlert("DB connection error", "Huddle System");
                         hideLoadingIcon();
                         }
                         });
                  } else {
                  showAlert("Please check internet connection.", "Huddle System");
                  hideLoadingIcon();
                  }
                  });
}


/* ChangePage function*/

function changePage(pagename, pageTransition, isReverse) {
    $.mobile.changePage(pagename, {
                        transition: pageTransition,
                        changeHash: false,
                        reverse: isReverse
                        });
    
}


function loginPageFunction(){
    
    currentActivePage = $.mobile.activePage.attr("id");
    
}

/*Login Functionality*/

function loginIn() {
 
    if (($("#userName").val() == '') && ($("#password").val() == ''))
        showAlert("Please Enter Username And Password", "Huddle System");
    else if ($("#userName").val() == '')
        showAlert("Please Enter Username", "Huddle System");
    else if ($("#password").val() == '')
        showAlert("Please Enter Password", "Huddle System");
    else {
        
        var source = device.platform;
        if(source=="iOS"){
            source="ios";
        }else if(source=="Android"){
            source="android";
        }
        parameters = {
            "username": "" + $("#userName").val() + "",
            "password": "" + $("#password").val() + "",
            "device_id": localStorage.getItem("DevieToken"),
            "source": source
        };
//        "device_id": localStorage.getItem("DevieToken"),
//        "source": source
        if ($("#rememberMecheckBox").prop("checked")) {
            localStorage.setItem("singleSignOn", "true");
        } else {
            localStorage.setItem("singleSignOn", "false");
        }
        
        hurdleSystemWebService("Post", "signin", parameters, function(response) {
                               
                               var obj = JSON.parse(response);
                               if (obj.msg == "Success") {
                               console.log(JSON.stringify(obj));
                               localStorage.setItem("userName",obj.username);
                               localStorage.setItem("passWord",$("#password").val());
                               $("#loginForm").trigger("reset");
                               localStorage.setItem("userId", obj.user_id);
                               localStorage.setItem("isLoggedOut","No");
                               changePage("#firstHurdlePg", "slide", false);
                               hideLoadingIcon();
                               } else {
                               showAlert("Please Enter Correct Username And Password", "Huddle System");
                               hideLoadingIcon();
                               }
                               });
        
    }
}
/*End of Login Functionality*/

/*Forgot password page reset*/

function forgotPasswordPgFormReset(){
    
    $("#resetPasswordForm").trigger("reset");
    
}

/*End of forgot password page reset*/


/*change password functionality*/

function changePassword(){
    
    //    $("#forgotPasswordPgUserName").val() == '') &&  else if ($("#forgotPasswordPgUserName").val() == '')
//    showAlert("Please Enter Username", "Huddle System");
//    else if ((localStorage.getItem("userName"))!=$("#forgotPasswordPgUserName").val())
//        showAlert("Username Doesn't Match", "Huddle System");
    
    
    if (($("#forgotPasswordPgOldPassword").val() == '') && ($("#forgotPasswordPgNewPassword").val() == '')&& ($("#forgotPasswordPgConfirmNewPassword").val() == ''))
        showAlert("Please Enter All Fields", "Huddle System");
    else if ($("#forgotPasswordPgOldPassword").val() == '')
        showAlert("Please Enter Old Password", "Huddle System");
    else if ($("#forgotPasswordPgNewPassword").val() == '')
        showAlert("Please Enter New Password", "Huddle System");
    else if ($("#forgotPasswordPgConfirmNewPassword").val() == '')
        showAlert("Please Enter Confirm New Password", "Huddle System");
    else if ((localStorage.getItem("passWord"))!=($("#forgotPasswordPgOldPassword").val()))
        showAlert("Old Password Doesn't Match", "Huddle System");
   
    else if(($("#forgotPasswordPgNewPassword").val()) == ($("#forgotPasswordPgConfirmNewPassword").val())){
        parameters = {
            "user_id": "" + localStorage.getItem("userId") + "",
            "old_pwd": "" + $("#forgotPasswordPgOldPassword").val() + "",
            "new_pwd": "" + $("#forgotPasswordPgNewPassword").val() + ""
        };
        
    hurdleSystemWebService("Post", "change_password", parameters, function(response) {
                           var obj = JSON.parse(response);
                           if (obj.msg == "Success") {
                           changePage("#loginPg","slide",false);
                           hideLoadingIcon();
                           } else {
                           showAlert("Cannot Change Password", "Huddle System");
                           hideLoadingIcon();
                           }
                           });
    
    }else{
        
        showAlert("New Password Did Not Match With Confirm New Password", "Huddle System");
        
    }
    
    
    
}

/*End of functionality*/

//
//function setDate(){
//
//    var now = new Date();
//    var day = ("0" + now.getDate()).slice(-2);
//    var month = ("0" + (now.getMonth() + 1)).slice(-2);
//    var today = now.getFullYear()+"-"+(month)+"-"+(day);
//    $("#hurdleFromDate").val(today);
//    $("#hurdleToDate").val(today);
//    $("#resolutionDate").val(today);
//
//}

/*Resetting login page form */

function resetLoginPg() {
    $("#loginForm").trigger("reset");
    
}

/*End of Resetting login page form */


/*Logout Alert Functionality */

function logout() {
    navigator.notification.confirm("Are you sure you want to logout?", btnLabel, "Logout", ["Yes", "No"]);
}

function btnLabel(buttonIndex) {
    if (buttonIndex == 1) {
        localStorage.setItem("singleSignOn", "false");
        localStorage.setItem("isLoggedOut", "Yes");
        changePage("#loginPg", "slide");
    }else{
        localStorage.setItem("isLoggedOut", "No");
    }
    
}

/*End of Logout Alert Functionality */


/*Getting Hurdle Count functionality for FirstPg*/

function getHurdleCount() {
    
    currentActivePage = $.mobile.activePage.attr("id");
    
    parameters = {
        "offset": 0,
        "limit": 1
    };
    
    hurdleSystemWebService("Post", "list_all_hurdles", parameters, function(response) {
                          
                           var obj = JSON.parse(response);
                           if (obj.msg == "Success") {
//                         alert("hurdlecount"+JSON.stringify(response));
                           $("#todayHurdleCount").html(obj.counthurdletoday);
                           $("#hurdleCount").html(obj.totalhurdlecount);
                           $("#weeklyHurdleCount").html(obj.counthurdleweek);
                           $("#monthlyHurdleCount").html(obj.counthurdlemonth);
                            //alert(obj.counthurdletoday);
                           /*To show alert to user initally when user click zero count hurdle*/
                           
                           if(obj.counthurdletoday==0){
                           TodayHurdleCountZero=1;
                           }else{
                           TodayHurdleCountZero=0;
                           }
                           
                           if(obj.counthurdleweek==0){
                           WeeklyHurdleCountZero=1;
                           }else{
                           WeeklyHurdleCountZero=0;
                           }
                           
                           if(obj.counthurdlemonth==0){
                           MonthlyHurdleCountZero=1;
                           }else{
                           MonthlyHurdleCountZero=0;
                           }
                           
                           hurdleSystemWebService("Post", "list_all_reminders", parameters, function(response) {
                                                  
                                                  var obj = JSON.parse(response);
                                                  console.log("remindercount"+JSON.stringify(response));
                                                  if (obj.msg == "Success") {
                                                  $("#todayRemainderCount").html(obj.countremindertoday);
                                                  $("#totalRemainderCount").html(obj.totalremindercount);
                                                  $("#weeklyReminderCount").html(obj.countreminderweek);
                                                  $("#monthlyReminderCount").html(obj.countremindermonth);
                                                  
                                                  if(obj.countremindertoday==0){
                                                  TodayReminderCountZero = 1;
                                                  }else{
                                                  TodayReminderCountZero = 0;
                                                  }
                                                  
                                                  if(obj.countreminderweek==0){
                                                  WeeklyReminderCountZero = 1;
                                                  }else{
                                                  WeeklyReminderCountZero = 0;
                                                  }
                                                  
                                                  if(obj.countremindermonth==0){
                                                  MonthlyReminderCountZero = 1;
                                                  }else{
                                                  MonthlyReminderCountZero = 0;
                                                  }
                                                  
                                                  hideLoadingIcon();
                                                  } else {
                                                  hideLoadingIcon();
                                                  showAlert("Webservice Error", "Huddle System");
                                                  }
                                                  });
                           
                           } else {
                           hideLoadingIcon();
                           showAlert("Webservice Error", "Huddle System");
                           }
                           });
  
}

/*End of Getting Hurdle Count functionality for FirstPg*/




/*Finding scroll event for every page and used to navigate next hurdle page list and show the refresh icon in top and bottom of page*/


$("#filterHurdlePg").on("scrollstop", function() {

                        if ($(window).scrollTop() === 0) {
                        
                       if((localStorage.getItem("offset")==0)&&(localStorage.getItem("limit")==10)){
//alert("off"+localStorage.getItem("offset")+"lmt"+localStorage.getItem("limit")+"todayhurdle"+localStorage.getItem("todayhurdle"));
                        listHurdleWebService(localStorage.getItem("offset"), localStorage.getItem("limit"), localStorage.getItem("todayhurdle"));
                           }
                        
                        $("#nextHurdle").hide();
//                        console.log("reachedtop'"+$(document).height()+"'");
                        console.log("reachedtop");
                        if (localStorage.getItem("offset") == 0) {
                        $("#previousHurdle").hide();
                        //showAlert("No New Hurdles", "Hurdle System");
                        } else {
                        
                        //                        listHurdleWebService(offset,limit);
                        $("#topRefreshButton").html("<a href='#' style='margin-left:45% !important;' id='previousHurdle' class='ui-btn ui-icon-carat-u ui-btn-icon-notext ui-corner-all blue-color' onclick=''></a>");
                        $("#topRefreshButton").show();
                        }
                        }else if ($(window).scrollTop() == $(document).height() - $(window).height()) {
                        console.log("reachedend");
                        //                        alert(limit+""+localStorage.getItem("totalhurdlecount")+""+$(document).height());
                        $("#previousHurdle").hide();
                        if (limit < localStorage.getItem("totalhurdlecount")) {
                        
                        $("#downRefreshButton").html("<a href='#' style='margin-left:45% !important;' id='nextHurdle' class='ui-btn ui-icon-carat-d ui-btn-icon-notext ui-corner-all blue-color' style='' onclick=''></a>");
                        $("#downRefreshButton").show();
                        
                        } else {
                        $("#nextHurdle").hide();
                        //showAlert("No Hurdles", "Hurdle System");
                        }
                        //listHurdleWebService(offset,limit);
                        }
                        });


/*End of Functionality*/

/*If filterhurdle page reaches top limit and offset will get reduced by 10*/

$("#topRefreshButton").click(function() {
                             offset = offset - 10;
                             limit = limit - 10;
                             localStorage.setItem("offset", "");
                             localStorage.setItem("offset", offset);
                             localStorage.setItem("limit", "");
                             localStorage.setItem("limit", limit);
                             
                             listHurdleWebService(offset, limit, localStorage.getItem("todayhurdle"));
                             $("#topRefreshButton").hide();
                             
                             });

/*End of Functionality*/

/*If filterhurdle page reaches bottom limit and offset will get increased by 10*/

$("#downRefreshButton").click(function() {
                              
                              offset = offset + 10;
                              limit = limit + 10;
                              localStorage.setItem("offset", "");
                              localStorage.setItem("offset", offset);
                              localStorage.setItem("limit", "");
                              localStorage.setItem("limit", limit);
                              
                              listHurdleWebService(offset, limit, localStorage.getItem("todayhurdle"));
                              $("#nextHurdle").hide();
                              });

/*End of Functionality*/


/*To check whether today's hurdle need to be viewed of all hurdle */

function hurdleValue(today) {
    
    offset = 0;
    limit = 10;
    
    $("#topRefreshButton").hide();
    $("#downRefreshButton").hide();
    
    if (today == 1) {
        
        /* 1 Represents Today's Count*/
        localStorage.setItem("todayhurdle", "1");
        //        listHurdleWebService(0,10,1);
        currentActivePage = $.mobile.activePage.attr("id");
        off = 0;
        lmt = 10;
        localStorage.setItem("offset", "0");
        localStorage.setItem("limit", "10");

        if(TodayHurdleCountZero==1){
            showAlert("No Hurdle", "Huddle System");
        }else{
             changePage("#filterHurdlePg", "slide", false);
        }
    }else if(today == 7){
        
        /*7 Represents Weekly Count*/
        localStorage.setItem("todayhurdle", "7");
        currentActivePage = $.mobile.activePage.attr("id");
        off = 0;
        lmt = 10;
        localStorage.setItem("offset", "0");
        localStorage.setItem("limit", "10");
        
        if(WeeklyHurdleCountZero==1){
            showAlert("No Hurdle", "Huddle System");
        }else{
            changePage("#filterHurdlePg", "slide", false);
        }

    }else if(today == 30){
        
        /*30 Represents Monthly Count*/
        localStorage.setItem("todayhurdle", "30");
        currentActivePage = $.mobile.activePage.attr("id");
        off = 0;
        lmt = 10;
        localStorage.setItem("offset", "0");
        localStorage.setItem("limit", "10");
       
        if(MonthlyHurdleCountZero==1){
            showAlert("No Hurdle", "Huddle System");
        }else{
            changePage("#filterHurdlePg", "slide", false);
        }
    }
    else {
        localStorage.setItem("todayhurdle", "0");
        //listHurdleWebService(0,10,0);
        currentActivePage = $.mobile.activePage.attr("id");
        off = 0;
        lmt = 10;
        localStorage.setItem("offset", "0");
        localStorage.setItem("limit", "10");
        changePage("#filterHurdlePg", "slide", false);
        
    }
}

/*End of Functionality*/

/*From hurdlelist page back will call this function*/

function backFromSearch() {
    
    currentActivePage = "filterHurdlePg";
    changePage('#filterHurdlePg', 'slide', true);
    
}
/*End of Functionality*/

function toHurdleSearchPg() {
    //    off=0;
    //    lmt=10;
    //    localStorage.setItem("offset","0");
    //    localStorage.setItem("limit","10");
    
    changePage("#searchHurdlePg", "slide", false);
    
    
}

/*List Hurdle Functionality*/

function listHurdleWebService(off, lmt, todayhurdle) {
    
    /*To avoid frequent loading after view hurdle to hurdle list page*/
    
    if((currentActivePage=="viewHurdlePg") && (showHurdleListFromNoti == 0)){
        console.log("dontLoad");
    }else{
        
        showHurdleListFromNoti = 0;
    var title;
    $('input[data-type="search"]').val("");
    
    console.log(off);
    console.log(lmt);
    
    if (currentActivePage == "searchHurdlePg") {
        if($("#leadName").val()=="Lead Name"){
            parameters = {
                "offset": off,
                "limit": lmt,
                "hurdle_type_id": $("#hurdleType").val(),
//                "user_id": localStorage.getItem("userId"),
                "from_date": $("#hurdleFromDate").val(),
                "to_date": $("#hurdleToDate").val(),
                "status": $("#searchHurdleStatus").val(),
                "lead_name": ""
                
            };

        }else{
            parameters = {
                "offset": off,
                "limit": lmt,
                "hurdle_type_id": $("#hurdleType").val(),
//                "user_id": localStorage.getItem("userId"),
                "from_date": $("#hurdleFromDate").val(),
                "to_date": $("#hurdleToDate").val(),
                "status": $("#searchHurdleStatus").val(),
                "lead_name": $("#leadName").val()
                
            };
            
 
        }
        
        //        alert(off+""+lmt+""+$("#hurdleType").val()+""+localStorage.getItem("userId")+""+$("#hurdleFromDate").val()+""+$("#hurdleToDate").val()+""+$("#searchHurdleStatus").val()+""+$("#leadName").val());
        //         changePage("#filterHurdlePg","slide",false);
        
    } else {
        
        if (todayhurdle == 1) {
            
            parameters = {
                "offset": off,
                "limit": lmt,
                "today": 1,
                "status": "open"
            };
            
        }else if(todayhurdle == 7){
            parameters = {
                "offset": off,
                "limit": lmt,
                "week": 1,
                "status": "open"
            };
        
        }else if(todayhurdle == 30){
            parameters = {
                "offset": off,
                "limit": lmt,
                "month": 1,
                "status": "open"
            };

        }else {
            
            parameters = {
                "offset": off,
                "limit": lmt
            };
        }
    }
    
    hurdleSystemWebService("Post", "list_all_hurdles", parameters, function(response) {
                           $("#hurdleList").empty();
                           var obj = JSON.parse(response);
                           //alert(off+"s"+lmt+"as"+todayhurdle);
                           console.log(JSON.stringify(response));
                           if (obj.msg == "Success") {
//console.log("This is list"+JSON.stringify(response));
                           hideLoadingIcon();
                           localStorage.setItem("totalhurdlecount", "");
                           localStorage.setItem("totalhurdlecount", obj.totalhurdlecount);
                           if (($(window).height() < 700) && ($(window).width() < 400)) {
                           for (var i = 0; i <= obj.totalcount; i++) {
                           year = obj[i].hurdle_date.split("-")[0];
                           monthName = arry[obj[i].hurdle_date.split("-")[1]];
                           todayDate = obj[i].hurdle_date.split("-")[2];
                           webServiceDataConversion[i] = monthName + "-" + todayDate;
                           
                           /*To check whether title is empty or not*/
                           
                           if (obj[i].title == "" || obj[i].title == " ") {
                           title = "No Title"
                           } else {
                           title = obj[i].title;
                           }
                           //console.log(JSON.stringify(response));
                           //not viewed
                           if (obj[i].description.split(" ").length > 100) {
                           fullDescMsg = obj[i].description;
                           shortMsg = obj[i].description.substring(0, 200);
                           
                           $("#hurdleList").append("<li data-icon='false'><a href='#' onclick='viewHurdlePage(" + obj[i].id + "," + obj[i].viewed + ");'>\
                                                   <div class='ui-grid-b hurdleListFontSizeLarge'>\
                                                   <div class='ui-block-a' style='width:10% !important;'><p id='readunreadmsg" + obj[i].id + "'></p></div>\
                                                   <div class='ui-block-b' style='width:35% !important;'><p><b>"+ obj[i].clientname +"</b></p></div>\
                                                   <div class='ui-block-c' style='width:35% !important;'><p><b>"+ obj[i].username +"</b></p></div>\
                                                   <div class='ui-block-d' style='width:20% !important;'><p class='hurdleListDate" + i + "' style='float:right'></p></div>\
                                                   </div>\
                                                   <p style='white-space:pre-line;font-size:large;' class='descp' id=" + obj[i].id + "descp>" + shortMsg + "</p><p class='descriptionContent' id=" + obj[i].id + "2\ style='white-space:normal;overflow:scroll;font-size:large;'>" + fullDescMsg + "</p>\
                                                   <p style='float:left;' id=" + obj[i].id + "lcusername></p>\
                                                   <p style='float:right;' id=" + obj[i].id + "statuscolor></p>\
                                                   </a><li data-icon='false'><a href='#'><p id=" + obj[i].id + " style='font-size:small !important;float:right'>More</p></a></li></li>");

                           //                           if(obj[i].status=="Closed"){
                           //                           $("#"+obj[i].id+"statuscolor").html("<b>"+obj[i].status+"</b>");
                           //                           $("#"+obj[i].id+"statuscolor").css("color", "red");
                           //                           }else if(obj[i].status=="Active"){
                           //                           $("#"+obj[i].id+"statuscolor").html("<b>"+obj[i].status+"</b>");
                           //                           $("#"+obj[i].id+"statuscolor").css("color", "green");
                           //                           }
                           
                           if (obj[i].viewed == 0) {
                           
                           $("#readunreadmsg" + obj[i].id + "").append("<img src='img/unReadMsg.png' style='height:10px;width:10px;float:left;'/>");
                           
                           } else {
                           console.log("readmsg");
                           }
                           $("#hurdleList").listview("refresh");
                           $(".descriptionContent").hide();
                           $(".hurdleListDate" + i).html("<i><b>" + webServiceDataConversion[i] + "</b></i>");
                           
                           $("#" + obj[i].id).click(function() {
                                                    toggleDescription($(this).attr("id"), $(this).attr("id") + "2", $(this).attr("id") + "descp");
                                                    
                                                    });
                           
                           } else {
                           /*if no of words not greater than 100 words it will be displayes as such without more options*/
                           $("#hurdleList").append("<li data-icon='false'><a href='#' onclick='viewHurdlePage(" + obj[i].id + "," + obj[i].viewed + ");'>\
                                                   <div class='ui-grid-b hurdleListFontSizeLarge' >\
                                                   <div class='ui-block-a' style='width:10% !important;'><p id='readunreadmsg" + obj[i].id + "''></p></div>\
                                                   <div class='ui-block-b' style='width:35% !important;'><p><b>"+ obj[i].clientname +"</b></p></div>\
                                                   <div class='ui-block-c' style='width:35% !important;'><p><b>" + obj[i].username + "</p></b></div>\
                                                   <div class='ui-block-d' style='width:20% !important;'><p class='hurdleListDate" + i + "' style='float:right'></p></div><br>\
                                                   </div>\
                                                   <p style='white-space:pre-line;font-size:large;' id='descp'>" + obj[i].description + "</p>\
                                                   <p style='float:left;' id=" + obj[i].id + "lcusername></p>\
                                                   <p style='float:right;' id=" + obj[i].id + "statuscolor></p>\
                                                   </a></li>");
                           
                           if (obj[i].viewed == 0) {
                           
                           $("#readunreadmsg" + obj[i].id + "").html("<img src='img/unReadMsg.png' style='height:10px;width:10px;float:left;'/>");
                           
                           } else {
                           
                           console.log("readmsg");
                           
                           }
                           
                           $("#hurdleList").listview("refresh");
                           $(".descriptionContent").hide();
                           $(".hurdleListDate" + i).html("<i><b>" + webServiceDataConversion[i] + "</b></i>");
                           
                           $("#" + obj[i].id).click(function() {
                                                    toggleDescription($(this).attr("id"));
                                                    });
                           }
                           if (obj[i].status == "Closed") {
                           $("#" + obj[i].id + "statuscolor").html("<b>" + obj[i].status + "</b>");
                           $("#" + obj[i].id + "statuscolor").css("color", "#900000");
                           
//                           for demo url status for hurdle is Active and Closed for live url status is Open and Closed
                           
                           } else if (obj[i].status == "Open") {
                           $("#" + obj[i].id + "statuscolor").html("<b>" + obj[i].status + "</b>");
                           $("#" + obj[i].id + "statuscolor").css("color", "green");
                           }
                           
                           //last comment user name checking whether it is empty or not
                           
                           if ((obj[i].lcusername == "")||(obj[i].lcusername == " ")) {
                           $("#" + obj[i].id + "lcusername").html("<b><i>No Comments</i></b>");
                           
                           
                           } else if ((obj[i].lcusername != "")||(obj[i].lcusername != " ")) {
                           $("#" + obj[i].id + "lcusername").html("<b><i>" +obj[i].lcusername+ " Commented</i></b>");
                           }
                           
                           }
                           
                           //Larger Devices
                           
                           } else {
                           for (var i = 0; i <= obj.totalcount; i++) {
                           year = obj[i].hurdle_date.split("-")[0];
                           monthName = arry[obj[i].hurdle_date.split("-")[1]];
                           todayDate = obj[i].hurdle_date.split("-")[2];
                           webServiceDataConversion[i] = monthName + "-" + todayDate;
                           
                           if (obj[i].title == "" || obj[i].title == " ") {
                           title = "No Title"
                           } else {
                           title = obj[i].title;
                           }
                           // not viewed hurdle
                           
                           $("#hurdleList").append("<li data-icon='false'><a href='#' onclick='viewHurdlePage(" + obj[i].id + "," + obj[i].viewed + ");'>\
                                                   <div class='ui-grid-b hurdleListFontSizeLarge' >\
                                                   <div class='ui-block-a' style='width:10% !important;'><p id='readunreadmsg" + obj[i].id + "'></p></div>\
                                                   <div class='ui-block-b' style='width:35% !important;'><p><b>"+ obj[i].clientname +"</b></p></div>\
                                                   <div class='ui-block-c' style='width:35% !important;'><p><b>" + obj[i].username + "</p></b></div>\
                                                   <div class='ui-block-d' style='width:20% !important;'><p class='hurdleListDate" + i + "' style='float:right'></p></div><br>\
                                                   </div>\
                                                   <p style='white-space:pre-line;font-size:large;' class='descp' id=" + obj[i].id + "descp>" + obj[i].description + "</p>\
                                                   <p style='float:left;' id=" + obj[i].id + "lcusername></p>\
                                                   <p style='float:right;' id=" + obj[i].id + "statuscolor></p>\
                                                   </a></li>");
                           if (obj[i].viewed == 0) {
                           
                           $("#readunreadmsg" + obj[i].id + "").append("<img src='img/unReadMsg.png' style='height:10px;width:10px;float:left;'/>");
                           
                           } else {
                           console.log("readmsg");
                           }
                           $("#hurdleList").listview("refresh");
                           $(".descriptionContent").hide();
                           $(".hurdleListDate" + i).html("<i><b>" + webServiceDataConversion[i] + "</b></i>");
                           
                           if (obj[i].status == "Closed") {
                           $("#" + obj[i].id + "statuscolor").html("<b>" + obj[i].status + "</b>");
                           $("#" + obj[i].id + "statuscolor").css("color", "#900000");
                           } else if (obj[i].status == "Active") {
                           $("#" + obj[i].id + "statuscolor").html("<b>" + obj[i].status + "</b>");
                           $("#" + obj[i].id + "statuscolor").css("color", "green");
                           }
                           
                           
                           //last comment user name checking whether it is empty or not
                           
                           if ((obj[i].lcusername == "")||(obj[i].lcusername == " ")) {
                           $("#" + obj[i].id + "lcusername").html("<b><i>No Comments</i></b>");
                           
                           
                           } else if ((obj[i].lcusername != "")||(obj[i].lcusername != " ")) {
                           $("#" + obj[i].id + "lcusername").html("<b><i>" +obj[i].lcusername+ " Commented</i></b>");
                           }
                           
                           }
                           }
                           } else if (obj.msg == "No Hurdle") {
                           if (currentActivePage == "firstHurdlePg") {
                           showAlert("No Hurdle", "Huddle System", function() {
                                     changePage("#firstHurdlePg", "slide", true);
                                     });
                           
                           } else if (currentActivePage == "searchHurdlePg")
                           showAlert("No Hurdle", "Huddle System", function() {
                                     changePage("#searchHurdlePg", "slide", true);
                                     });
                           hideLoadingIcon();
                           } else {
                           showAlert("Webservice Error", "Huddle System");
                           hideLoadingIcon();
                           }
                           });
    $(window).scrollTop(10);
}
}



/*End of Functionality*/

/*Functionality to change more to less and less to more in hurdle list*/

function toggleDescription(id, i, descpid) {
    
    if ($("#" + id).text() == "More") {
        
        //        $(".descp").hide();
        //        $(".descriptionContent").hide();
        
        $("#" + descpid).hide();
        $("#" + i).hide();
        $("#" + id).html("Less");
        $("#" + i).toggle("slow");
        
    } else {
        
        //        $(".descp").show();
        //        $(".descriptionContent").show();
        
        $("#" + descpid).show();
        $("#" + i).show();
        $("#" + id).html("More");
        $("#" + i).toggle("slow");
    }
    
}
/*End of Functionality*/

/*Functionality call navigated to view hurdle page and also hurdleid and whether hurdle viewed is set in here*/

function viewHurdlePage(hurdleid, isviewed) {
    
//    currentActivePage = $.mobile.activePage.attr("id");
    
    localStorage.setItem("hurdleId", hurdleid);
    localStorage.setItem("isViewed", "");
    localStorage.setItem("isViewed", isviewed);
    
    changePage("#viewHurdlePg", "slide", false);
    
}

/*End of Functionality*/


/* Functionality for Viewing hurdle details*/

function viewHurdleDetails() {
    
    $("#addCommentPageContent").hide();
    //alert(localStorage.getItem("hurdleId")+"====="+localStorage.getItem("isViewed"));

    currentActivePage = $.mobile.activePage.attr("id");
    parameters = {
    hurdle_id: localStorage.getItem("hurdleId"),
    is_viewed: localStorage.getItem("isViewed")
    };
    hurdleSystemWebService("Post", "view_hurdle", parameters, function(response) {
                           console.log(JSON.stringify(response));
                           $("#viewHurdle").empty();
                           $("#viewHurdleComments").empty();
                           var obj = JSON.parse(response);
                           console.log("vidwhurdledetails"+JSON.stringify(response));
                           
                           localStorage.setItem("clientNameForPushNotification","");
                           localStorage.setItem("clientNameForPushNotification",obj.clientname);
                           localStorage.setItem("hurdleDateForPushNotification","");
                           localStorage.setItem("hurdleDateForPushNotification",obj.hurdle_date);
                           
                           if (obj.msg == "Success") {
                           $("#viewHurdlePgCloseBtn").show();
                           $("#viewHurdlePgAddCommentBtn").show();
                           $("#viewHurdle").html("<li data-icon='false'>\
                                                 <div class='ui-grid-b' style='font-size:small !important;background-color:#f1f1f1;'><b>\
                                                 <div class='ui-block-a' style='width:33% !important;padding-left:2% !important;'>" + obj.type + "</div>\
                                                 <div class='ui-block-b' style='width:33% !important;white-space: nowrap !important;overflow: hidden !important;text-overflow: ellipsis;'>" + obj.clientname + "</div>\
                                                 <div class='ui-block-c' style='width:33% !important;padding-left:2% !important; text-align: right !important;'>" + obj.raised_by + "</div></b><br>\
                                                 <div class='viewHurdleDescription' style='font-size:90% !important;'><b>Description: </b>" + obj.description + "<br><b>Response: </b>" + obj.root_cause + "<br><b>Status: </b>" + obj.status + "</div></div>\
                                                 </li>");
                           
                           if (obj.status == "Closed") {
                           
                           $("#viewHurdlePgCloseBtn").addClass("borderthickness");
                           $("#viewHurdlePgAddCommentBtn").addClass("borderthickness");
                           
                           $("#viewHurdlePgCloseBtn").addClass("ui-disabled");
                           $("#viewHurdlePgAddCommentBtn").addClass("ui-disabled");
                           $("#addHurdleCommentIcon").addClass("ui-disabled");
                           
                           
                           } else if (obj.status == "Open") {
                           
                           $("#viewHurdlePgCloseBtn").removeClass("borderthickness");
                           $("#viewHurdlePgAddCommentBtn").removeClass("borderthickness");
                           
                           $("#viewHurdlePgCloseBtn").removeClass("ui-disabled");
                           $("#viewHurdlePgAddCommentBtn").removeClass("ui-disabled");
                           $("#addHurdleCommentIcon").removeClass("ui-disabled");
                           }
                           
                           var totalHurdleCommentCount = obj.comments.length;
                           for (var i = 0; i < obj.comments.length; i++) {
                           
                           if((obj.status=="Closed")&&(i== (totalHurdleCommentCount-1))){
                           
                           year = obj.resolution_date.split("-")[0];
                           monthName = arry[obj.resolution_date.split("-")[1]];
                           todayDate = obj.resolution_date.split("-")[2];
                           webServiceDataConversion[i] = monthName + "-" + todayDate + "-" + year;
                           
                           }else{
                           
                           year = obj.comments[i].created.split("-")[0];
                           monthName = arry[obj.comments[i].created.split("-")[1]];
                           todayDate = obj.comments[i].created.split("-")[2];
                           webServiceDataConversion[i] = monthName + "-" + todayDate + "-" + year;
                           
                           }
                           if (localStorage.getItem("userId") == obj.comments[i].user_id) {
                           
                           
                           $("#viewHurdleComments").append("<li data-icon='false'><div style='background-color:#cbe5f8;'>\
                                                           <p class='viewHurdleDescription' style='font-size:small !important;padding-left:2px !important;'>" + obj.comments[i].description + "</p>\
                                                           <div class='ui-grid-b hurdleListFontSize'>\
                                                           <div class='ui-block-a'><p style='\
                                                           font-size:smaller !important;padding-left:2px !important;'>" + webServiceDataConversion[i] + "</p></div>\
                                                           <div class='ui-block-b' style='padding-left:5% !important;'><p style='\
                                                           font-size:smaller !important;'><b>" + obj.comments[i].username + "<b></p></div>\
                                                           <div class='ui-block-c' style='float:right !important;'><p class='viewHurdleTime' style='\
                                                           font-size:smaller !important;padding-right:2px !important;'>" + obj.comments[i].created_time + "</p></div></div></div>\
                                                           </li>");
                           $("#viewHurdleComments").listview("refresh");
                           } else {
                           $("#viewHurdleComments").append("<li data-icon='false'><div style='background-color:#f1f1f1;'>\
                                                           <p class='viewHurdleDescription'  style='\
                                                           font-size:small !important;padding-left:2px !important;'>" + obj.comments[i].description + "</p>\
                                                           <div class='ui-grid-b hurdleListFontSize'>\
                                                           <div class='ui-block-a'><p style='\
                                                           font-size:smaller !important;padding-left:2px !important;'>" + webServiceDataConversion[i] + "</p></div>\
                                                           <div class='ui-block-b' style='padding-left:5% !important;'><p style='\
                                                           font-size:smaller !important;'><b>" + obj.comments[i].username + "<b></p></div>\
                                                           <div class='ui-block-c' style='float:right !important;'><p class='viewHurdleTime' style='\
                                                           font-size:smaller !important;padding-right:2px !important;'>" + obj.comments[i].created_time + "</p></div></div></div>\
                                                           </li>");
                           
                           $("#viewHurdleComments").listview("refresh");
                           
                           }
                           }
                           hideLoadingIcon();
                           
                           
                           /*Silent Scroll in view hurdle which go to end of page*/
//                           var target1 = $.mobile.activePage.find("#viewHurdleComments li:last-child").get(0).offsetTop;
//                           $.mobile.silentScroll(target1);
                           
                           } else {
                           showAlert("Webservice Error", "Huddle System");
                           hideLoadingIcon();
                           }
                           
                           });
    
}

/*End of Functionality*/


function showAddCommentContents(){
    $("#addCommentDescription").val("");
    $("#addCommentPageContent").toggle("slow");
}

/*Functionality for adding comment in add comment page */

function addComments() {
    
    if ($("#addCommentDescription").val() == " " || $("#addCommentDescription").val() == "") {
        showAlert("Please Add Description", "Huddle System");
    } else if ($("#addCommentStatus").val() == "1") {
        showAlert("Please Select Status", "Huddle System");
    } else {

        parameters = {
        hurdle_id: localStorage.getItem("hurdleId"),
        user_id: localStorage.getItem("userId"),
        description: $("#addCommentDescription").val(),
        status: "Active",
        username: localStorage.getItem("userName"),
        clientname: localStorage.getItem("clientNameForPushNotification"),
        created: localStorage.getItem("hurdleDateForPushNotification")
        };
        
        hurdleSystemWebService("Post", "add_hurdle_comments", parameters, function(response) {
                               console.log("one"+JSON.stringify(response));
                               var obj = JSON.parse(response);
                               if (obj.msg == "Success") {
                               $("#addCommentPageContent").toggle("slow");
                               hideLoadingIcon();
                               viewHurdleDetails();
                               } else {
                               hideLoadingIcon();
                               showAlert("Webservice Error", "Huddle System");
                               }
                               });
    }
}

/*End of Functionality*/


/*Functionality to load all select box in search hurdle page*/


function loadSearchPgSelectBoxes() {
    
    $("#topRefreshButton").hide();
    $("#downRefreshButton").hide();
    
    $("#hurdleFromDate").val(todayDateForSearchPage);
    $("#hurdleToDate").val(todayDateForSearchPage);
    
    $("#searchHurdleStatus").html("");
    $("#searchHurdleStatus").append("<option value=''>Status</option>");
    $("#searchHurdleStatus").append("<option value='Open'>Open</option>").selectmenu("refresh");
    $("#searchHurdleStatus").append("<option value='Closed'>Closed</option>").selectmenu("refresh");
    
    
    currentActivePage = $.mobile.activePage.attr("id");
    
    parameters = "";
    
    hurdleSystemWebService("Post", "get_hurdle_types", parameters, function(response) {
                           var obj = JSON.parse(response);
                           
                           if (obj.msg == "Success") {
                           //                           alert(JSON.stringify(response));
                           $("#hurdleType").html("");
                           $("#hurdleType").append("<option value='hurdletype' selected>Hurdle Type</option>");
                           for (var i = 0; i < obj.Hurdle_types.length; i++) {
                           $("#hurdleType").append("<option value=" + obj.Hurdle_types[i].id + ">" + obj.Hurdle_types[i].type + "</option>").selectmenu("refresh");
                           }
                           hideLoadingIcon();
                           } else {
                           hideLoadingIcon();
                           showAlert("Webservice Error", "Huddle System");
                           }
                           });
    
    hurdleSystemWebService("Post", "get_lead", parameters, function(response) {
                           var obj = JSON.parse(response);
                           if (obj.msg == "Success") {
                           //console.log(JSON.stringify(obj.Hurdle_types[0]));
                           $("#leadName").html("");
                           $("#leadName").append("<option value='Lead Name' selected>Lead Name</option>");
                           for (var i = 0; i < obj.users.length; i++) {
                           $("#leadName").append("<option value=" + obj.users[i].id + ">" + obj.users[i].employee_actual_name + "</option>").selectmenu("refresh");
                           }
                           hideLoadingIcon();
                           } else {
                           hideLoadingIcon();
                           showAlert("Webservice Error", "Huddle System");
                           }
                           });
    
}
/*End of Functionality*/

/*Validate Functionality for search hurdle page before search*/

function validateSearchPage() {
    
//    if ($("#hurdleType").val() == "hurdletype") {
//        showAlert("Please Select Hurdle Type", "Search Hurdle");
//        
//    } else if ($("#hurdleFromDate").val() == "" || $("#hurdleFromDate").val() == " ") {
//        showAlert("Please Enter From Date", "Search Hurdle");
//        
//    } else if ($("#hurdleToDate").val() == "" || $("#hurdleToDate").val() == " ") {
//        showAlert("Please Enter To Date", "Search Hurdle");
//        
//    } else if ($("#leadName").val() == "Lead Name") {
//        showAlert("Please Select Lead Name", "Search Hurdle");
//        
//    } else if ($("#searchHurdleStatus").val() == "Status") {
//        showAlert("Please Select Hurdle Status", "Search Hurdle");
//        
//    } else {
    
        //        listHurdleWebService(0,10,0);
        changePage("#filterHurdlePg", "slide", false);
        
//    }
    
}
/*End of Functionality*/

/* Functionality to reset search hurdle form*/

function resetSearchForm() {
    
    $("#searchHurdleForm").trigger("reset");
    
}

/*End of Functionality*/

/*Functionality to load all select box and description of close hurdle page*/

function loadClosureHurdleDetails() {
    $("#resolutionDate").val(todayDateForSearchPage);
    $("#closureComments").val("");
    currentActivePage = $.mobile.activePage.attr("id");
    parameters = {
    hurdle_id: localStorage.getItem("hurdleId")
    };
    hurdleSystemWebService("Post", "view_hurdle", parameters, function(response) {
                           var obj = JSON.parse(response);
                           console.log(JSON.stringify(response));
                           if (obj.msg == "Success") {
                           $("#closureHurdleDetails").html("<li data-icon='false'>\
                                                           <div class='ui-grid-b' style='font-size:smaller !important;background-color:#f1f1f1;'><b>\
                                                           <p><div class='ui-block-a' style='width:33% !important;padding-left:2% !important;'>" + obj.type + "</div>\
                                                           <div class='ui-block-b' style='width:33% !important;white-space: nowrap !important;overflow: hidden !important;text-overflow: ellipsis;'>" + obj.clientname + "</div>\
                                                           <div class='ui-block-c' style='width:33% !important;padding-left:2% !important; text-align: right !important;'>" + obj.raised_by + "</div></p></b><br>\
                                                           <div class='viewHurdleDescription' style='font-size:90% !important;'><b>Description: </b>" + obj.description + "<br><b>Response: </b>" + obj.root_cause + "<br><b>Status: </b>" + obj.status + "</div></div>\
                                                           </li>");
                           
                           
                           hideLoadingIcon();
                           } else {
                           showAlert("Webservice Error", "Huddle System");
                           hideLoadingIcon();
                           }
                           });
    
}

/*End of Functionality*/


/*Validate Functionality for close hurdle page before closing*/

function validateHurdleDetails() {
    
    if ($("#closureComments").val() == "" || $("#closureComments").val() == " ") {
        
        showAlert("Please Fill Description", "Close Hurdle");
        
    } else if ($("#resolutionDate").val() == "" || $("#resolutionDate").val() == " ") {
        
        showAlert("Please Enter Resolution Date", "Close Hurdle");
        
    } else {
        parameters = {
        hurdle_id: localStorage.getItem("hurdleId"),
        user_id: localStorage.getItem("userId"),
        resolution_date: $("#resolutionDate").val(),
        description: $("#closureComments").val(),
        status: "Closed"
        };
        
        hurdleSystemWebService("Post", "close_hurdle", parameters, function(response) {
                               var obj = JSON.parse(response);
                               //                               console.log("closehurdle"+JSON.stringify(response));
                               if (obj.msg == "Success") {
                               changePage("#viewHurdlePg", "slide", false);
                               hideLoadingIcon();
                               } else {
                               showAlert("Webservice Error", "Huddle System");
                               hideLoadingIcon();
                               }
                               });
        
        
    }
}

/*End of Functionality*/


/* To hide pagination button at top and bottom when moving back from viewhurdle page */
function fromViewHurdlePg() {
    
    localStorage.setItem("todayhurdle", "0");
    $("#previousHurdle").hide();
    $("#nextHurdle").hide();
    
}
/*End of Functionality*/

/*End of Hurdle Functionality*/




/*Start of Remainder Functionality*/

/*To check whether today's hurdle need to be viewed of all hurdle */

function remainderValue(today) {
    
    remainderOffset = 0;
    remainderLimit = 10;
    
    $("#previousRemainder").hide();
    $("#nextRemainder").hide();
    
    if (today == 1) {
        localStorage.setItem("todayremainder", "1");
        //listHurdleWebService(0,10,1);
        currentActivePage = $.mobile.activePage.attr("id");
        off = 0;
        lmt = 10;
        localStorage.setItem("remainderoffset", "0");
        localStorage.setItem("remainderlimit", "10");
        
        if(TodayReminderCountZero==1){
            showAlert("No Reminder", "Huddle System");
        }else{
            changePage("#filterRemainderPg", "slide", false);
        }
        
    }else if(today == 7){
        
        localStorage.setItem("todayremainder", "7");
        currentActivePage = $.mobile.activePage.attr("id");
        off = 0;
        lmt = 10;
        localStorage.setItem("remainderoffset", "0");
        localStorage.setItem("remainderlimit", "10");
        
        if(WeeklyReminderCountZero==1){
            showAlert("No Reminder", "Huddle System");
        }else{
            changePage("#filterRemainderPg", "slide", false);
        }

    }else if(today == 30){
        
        localStorage.setItem("todayremainder", "30");
        currentActivePage = $.mobile.activePage.attr("id");
        off = 0;
        lmt = 10;
        localStorage.setItem("remainderoffset", "0");
        localStorage.setItem("remainderlimit", "10");
        
        if(MonthlyReminderCountZero==1){
            showAlert("No Reminder", "Huddle System");
        }else{
            changePage("#filterRemainderPg", "slide", false);
        }
        
    }else {
        localStorage.setItem("todayremainder", "0");
        //listHurdleWebService(0,10,0);
        currentActivePage = $.mobile.activePage.attr("id");
        off = 0;
        lmt = 10;
        localStorage.setItem("remainderoffset", "0");
        localStorage.setItem("remainderlimit", "10");
        
        changePage("#filterRemainderPg", "slide", false);
        
    }
}

/*End of Functionality*/



function toRemainderSearchPg() {
    //        off=0;
    //        lmt=10;
    //        localStorage.setItem("remainderoffset","0");
    //        localStorage.setItem("remainderlimit","10");
    
    changePage("#searchRemainderPg", "slide", false);
    
}

/*List Remainder Functionality*/

function listRemainderWebService(off, lmt, todayremainder) {
    
    if((currentActivePage=="viewRemainderPg") && (showReminderListFromNoti == 0)){
        console.log("dontLoad");
    }else{
    
        showReminderListFromNoti = 0;
    var title;
    $('input[data-type="search"]').val("");
    
    console.log(off);
    console.log(lmt);
    if (currentActivePage == "searchRemainderPg") {
        
        
        if($("#RemainderleadName").val()=="Lead Name"){
            parameters = {
                "offset": off,
                "limit": lmt,
                "reminder_type_id": $("#RemainderType").val(),
//                "user_id": localStorage.getItem("userId"),
                "from_date": $("#RemainderFromDate").val(),
                "to_date": $("#RemainderToDate").val(),
                "status": $("#searchRemainderStatus").val(),
                "lead_name": ""
            };
            
        }else{
           
            parameters = {
                "offset": off,
                "limit": lmt,
                "reminder_type_id": $("#RemainderType").val(),
//                "user_id": localStorage.getItem("userId"),
                "from_date": $("#RemainderFromDate").val(),
                "to_date": $("#RemainderToDate").val(),
                "status": $("#searchRemainderStatus").val(),
                "lead_name": $("#RemainderleadName").val()
            };
            
        }
//
  
        
    } else {
        if (todayremainder == 1) {
            
            parameters = {
                "offset": off,
                "limit": lmt,
                "today": 1,
                "status":"open"
            };
            
        }else if(todayremainder == 7){
            
            parameters = {
                "offset": off,
                "limit": lmt,
                "week": 1,
                "status":"open"
            };

            
        }else if(todayremainder == 30){
            
            parameters = {
                "offset": off,
                "limit": lmt,
                "month": 1,
                "status":"open"
            };

            
        }
        else {
            parameters = {
                "offset": off,
                "limit": lmt
            };
        }
    }
    
    hurdleSystemWebService("POST", "list_all_reminders", parameters, function(response) {
                           $("#RemainderList").empty();
                           var obj = JSON.parse(response);
                           if (obj.msg == "Success") {
                           
                           console.log("asdf" + JSON.stringify(response));
                           //console.log("This is list"+JSON.stringify(response));
                           hideLoadingIcon();
                           localStorage.setItem("totalremaindercount", "");
                           localStorage.setItem("totalremaindercount", obj.totalremindercount);
                           
                           if (($(window).height() < 700) && ($(window).width() < 400)) {
                           for (var i = 0; i <= obj.totalcount; i++) {
                           year = obj[i].reminder_date.split("-")[0];
                           monthName = arry[obj[i].reminder_date.split("-")[1]];
                           todayDate = obj[i].reminder_date.split("-")[2];
                           webServiceDataConversion[i] = monthName + "-" + todayDate;
                           
                           /*To check whether title is empty or not*/
                           
                           if (obj[i].title == "" || obj[i].title == " ") {
                           title = "No Title"
                           } else {
                           title = obj[i].title;
                           }
                           //console.log(JSON.stringify(response));
                           //not viewed
                           
                           if (obj[i].description.split(" ").length > 100) {
                           fullDescMsg = obj[i].description;
                           shortMsg = obj[i].description.substring(0, 200);
                           
                           $("#RemainderList").append("<li data-icon='false'><a href='#' onclick='viewRemainderPage(" + obj[i].id + "," + obj[i].viewed + ");'>\
                                                      <div class='ui-grid-b hurdleListFontSizeLarge' >\
                                                      <div class='ui-block-a' style='width:10% !important;'><p id='remainderreadunreadmsg" + obj[i].id + "'></p></div>\
                                                      <div class='ui-block-b' style='width:35% !important;'><p><b>"+ obj[i].clientname +"</b></p></div>\
                                                      <div class='ui-block-c' style='width:35% !important;'><p><b>" + obj[i].username + "</p></b></div>\
                                                      <div class='ui-block-d' style='width:20% !important;'><p class='hurdleListDate" + i + "' style='float:right'></p></div><br>\
                                                      </div>\
                                                      <p style='white-space:pre-line;font-size:large;' class='descp' id=" + obj[i].id + "descp>" + shortMsg + "</p><p class='descriptionContent' id=" + obj[i].id + "2\ style='white-space:normal;overflow:scroll;font-size:large;'>" + fullDescMsg + "</p>\
                                                      <p style='float:left;' id=" + obj[i].id + "reminderlcusername></p>\
                                                      <p style='float:right;' id=" + obj[i].id + "remainderstatuscolor></p>\
                                                      </a><li data-icon='false'><a href='#'><p id=" + obj[i].id + " style='font-size:small !important;float:right'>More</p></a></li></li>");
                           if (obj[i].viewed == 0) {
                           
                           $("#remainderreadunreadmsg" + obj[i].id + "").append("<img src='img/unReadMsg.png' style='height:10px;width:10px;float:left;'/>");
                           
                           } else {
                           console.log("readmsg");
                           }
                           $("#RemainderList").listview("refresh");
                           $(".descriptionContent").hide();
                           $(".hurdleListDate" + i).html("<i><b>" + webServiceDataConversion[i] + "</b></i>");
                           
                           $("#" + obj[i].id).click(function() {
                                                    toggleDescription($(this).attr("id"), $(this).attr("id") + "2", $(this).attr("id") + "descp");
                                                    
                                                    });
                           
                           } else {
                           /*if no of words not greater than 100 words it will be displayes as such without more options*/
                           $("#RemainderList").append("<li data-icon='false'><a href='#' onclick='viewRemainderPage(" + obj[i].id + "," + obj[i].viewed + ");'>\
                                                      <div class='ui-grid-b hurdleListFontSizeLarge'>\
                                                      <div class='ui-block-a' style='width:10% !important;'><p id='remainderreadunreadmsg" + obj[i].id + "''></p></div>\
                                                      <div class='ui-block-b' style='width:35% !important;'><p><b>"+ obj[i].clientname +"</b></p></div>\
                                                      <div class='ui-block-c' style='width:35% !important;'><p><b>" + obj[i].username + "</b></p></div>\
                                                      <div class='ui-block-d' style='width:20% !important;'><p class='hurdleListDate" + i + "' style='float:right'></p></div><br>\
                                                      </div>\
                                                      <p style='white-space:pre-line;font-size:large;' id='descp'>" + obj[i].description + "</p>\
                                                      <p style='float:left;' id=" + obj[i].id + "reminderlcusername></p>\
                                                      <p style='float:right;' id=" + obj[i].id + "remainderstatuscolor></p>\
                                                      </a></li>");
                           if (obj[i].viewed == 0) {
                           
                        $("#remainderreadunreadmsg" + obj[i].id + "").html("<img src='img/unReadMsg.png' style='height:10px;width:10px;float:left;'/>");
                           
                           } else {
                           
                           console.log("readmsg");
                           
                           }
                           
                           $("#RemainderList").listview("refresh");
                           $(".descriptionContent").hide();
                           $(".hurdleListDate" + i).html("<i><b>" + webServiceDataConversion[i] + "</b></i>");
                           
                           $("#" + obj[i].id).click(function() {
                                                    toggleDescription($(this).attr("id"));
                                                    });
                           }
                           if (obj[i].status == "Closed") {
                           $("#" + obj[i].id + "remainderstatuscolor").html("<b>" + obj[i].status + "</b>");
                           $("#" + obj[i].id + "remainderstatuscolor").css("color", "#900000");
                           } else if (obj[i].status == "Open") {
                           $("#" + obj[i].id + "remainderstatuscolor").html("<b>" + obj[i].status + "</b>");
                           $("#" + obj[i].id + "remainderstatuscolor").css("color", "green");
                           }
                           
                           if ((obj[i].lcusername == "")||(obj[i].lcusername == " ")) {
                           $("#" + obj[i].id + "reminderlcusername").html("<b><i>No Comments</i></b>");
                           
                           
                           } else if ((obj[i].lcusername != "")||(obj[i].lcusername != " ")) {
                           $("#" + obj[i].id + "reminderlcusername").html("<b><i>" +obj[i].lcusername+ " Commented</i></b>");
                           }
                           
                           }
                           
                           //Larger Devices
                           
                           } else {
                           for (var i = 0; i <= obj.totalcount; i++) {
                           year = obj[i].reminder_date.split("-")[0];
                           monthName = arry[obj[i].reminder_date.split("-")[1]];
                           todayDate = obj[i].reminder_date.split("-")[2];
                           webServiceDataConversion[i] = monthName + "-" + todayDate;
                           
                           if (obj[i].title == "" || obj[i].title == " ") {
                           title = "No Title"
                           } else {
                           title = obj[i].title;
                           }
                           // not viewed reminders
                           
                           $("#RemainderList").append("<li data-icon='false'><a href='#' onclick='viewRemainderPage(" + obj[i].id + "," + obj[i].viewed + ");'>\
                                                      <div class='ui-grid-b hurdleListFontSizeLarge' >\
                                                      <div class='ui-block-a' style='width:10% !important;'><p id='remainderreadunreadmsg" + obj[i].id + "'></p></div>\
                                                      <div class='ui-block-b' style='width:35% !important;'><p><b>"+ obj[i].clientname +"</b></p></div>\
                                                      <div class='ui-block-c' style='width:35% !important;'><p><b>" + obj[i].username + "</p></b></div>\
                                                      <div class='ui-block-d' style='width:20% !important;'><p class='hurdleListDate" + i + "' style='float:right'></p></div><br>\
                                                      </div>\
                                                      <p style='white-space:pre-line;font-size:large;' class='descp' id=" + obj[i].id + "descp>" + obj[i].description + "</p>\
                                                      <p style='float:left;' id=" + obj[i].id + "reminderlcusername></p>\
                                                      <p style='float:right;' id=" + obj[i].id + "remainderstatuscolor></p>\
                                                      </a></li>");
                           
                           if (obj[i].viewed == 0) {
                           
                           $("#remainderreadunreadmsg" + obj[i].id + "").append("<img src='img/unReadMsg.png' style='height:10px;width:10px;float:left;'/>");
                           } else {
                           console.log("readmsg");
                           }
                           $("#RemainderList").listview("refresh");
                           $(".descriptionContent").hide();
                           $(".hurdleListDate" + i).html("<i><b>" + webServiceDataConversion[i] + "</b></i>");
                           
                           if (obj[i].status == "Closed") {
                           $("#" + obj[i].id + "remainderstatuscolor").html("<b>" + obj[i].status + "</b>");
                           $("#" + obj[i].id + "remainderstatuscolor").css("color", "#900000");
                           } else if (obj[i].status == "Open") {
                           $("#" + obj[i].id + "remainderstatuscolor").html("<b>" + obj[i].status + "</b>");
                           $("#" + obj[i].id + "remainderstatuscolor").css("color", "green");
                           }
                           //to identify who commented lastly on each reminder
                           if ((obj[i].lcusername == "")||(obj[i].lcusername == " ")) {
                           $("#" + obj[i].id + "reminderlcusername").html("<b><i>No Comments</i></b>");
                           
                           } else if ((obj[i].lcusername != "")||(obj[i].lcusername != " ")) {
                           $("#" + obj[i].id + "reminderlcusername").html("<b><i>" +obj[i].lcusername+ " Commented</i></b>");
                           }
                           
                           }
                           }
                           } else if (obj.msg == "No Reminders") {
                           if (currentActivePage == "searchRemainderPg") {
                           showAlert("No Reminder", "Huddle System", function() {
                                     changePage("#searchRemainderPg", "slide", true);
                                     });
                           } else if (currentActivePage == "firstHurdlePg") {
                           showAlert("No Reminder", "Huddle System", function() {
                                     changePage("#firstHurdlePg", "slide", true);
                                     });
                           }
                           hideLoadingIcon();
                           } else {
                           showAlert("Webservice Error", "Huddle System");
                           hideLoadingIcon();
                           }
                           });
    $(window).scrollTop(10);
}
}


/*End of Functionality*/


/*Finding scroll event for every page and used to navigate next hurdle page list and show the refresh icon in top and bottom of page*/


$("#filterRemainderPg").on("scrollstop", function() {
                           
                           
                           if ($(window).scrollTop() === 0) {
                           
                           if((localStorage.getItem("remainderoffset")==0)&&(localStorage.getItem("remainderlimit")==10)){
//                           alert("off"+localStorage.getItem("remainderoffset")+"lmt"+localStorage.getItem("remainderlimit")+"todayhurdle"+localStorage.getItem("todayremainder"));
                           listRemainderWebService(localStorage.getItem("remainderoffset"),localStorage.getItem("remainderlimit"), localStorage.getItem("todayremainder"));
                           }
                           
                           $("#nextRemainder").hide();
                           //alert(localStorage.getItem("remainderoffset"));
                           if (localStorage.getItem("remainderoffset") == 0) {
                           $("#previousRemainder").hide();
                           //showAlert("No New Hurdles", "Hurdle System");
                           } else {
                           
                           //listHurdleWebService(offset,limit);
                           $("#remainderListTopRefreshButton").html("<a href='#' style='margin-left:45% !important;' id='previousRemainder' class='ui-btn ui-icon-carat-u ui-btn-icon-notext ui-corner-all blue-color' onclick=''></a>");
                           $("#remainderListTopRefreshButton").show();
                           }
                           }else if ($(window).scrollTop() == $(document).height() - $(window).height()) {
                           $("#previousRemainder").hide();
//                           alert(remainderLimit+""+localStorage.getItem("totalremaindercount"));
                           if (remainderLimit < localStorage.getItem("totalremaindercount")) {
                           //                           alert(localStorage.getItem("totalremaindercount"));
                           //                           alert(localStorage.getItem("remainderoffset"));
                           //                           alert(localStorage.getItem("remainderlimit"));
                           $("#remainderListDownRefreshButton").html("<a href='#' style='margin-left:45% !important;' id='nextRemainder' class='ui-btn ui-icon-carat-d ui-btn-icon-notext ui-corner-all blue-color' style='' onclick=''></a>");
                           $("#remainderListDownRefreshButton").show();
                           
                           } else {
                           $("#nextRemainder").hide();
                           //showAlert("No Hurdles", "Hurdle System");
                           }
                           //listHurdleWebService(offset,limit);
                           }
                           });


/*End of Functionality*/

/*If filterhurdle page reaches top limit and offset will get reduced by 10*/

$("#remainderListTopRefreshButton").click(function() {
                                          
                                          remainderOffset = remainderOffset - 10;
                                          remainderLimit = remainderLimit - 10;
                                          localStorage.setItem("remainderoffset", "");
                                          localStorage.setItem("remainderoffset", remainderOffset);
                                          localStorage.setItem("remainderlimit", "");
                                          localStorage.setItem("remainderlimit", remainderLimit);
                                          
                                          //                                          alert("variable"+remainderOffset+""+remainderLimit);
                                          //                                          alert(localStorage.getItem("remainderoffset"));
                                          //                                          alert(localStorage.getItem("remainderlimit"));
                                          
                                          listRemainderWebService(remainderOffset, remainderLimit, localStorage.getItem("todayremainder"));
                                          $("#remainderListTopRefreshButton").hide();
                                          
                                          
                                          
                                          });

/*End of Functionality*/

/*If filterhurdle page reaches bottom limit and offset will get increased by 10*/

$("#remainderListDownRefreshButton").click(function() {
                                           
                                           remainderOffset = remainderOffset + 10;
                                           remainderLimit = remainderLimit + 10;
                                           localStorage.setItem("remainderoffset", "");
                                           localStorage.setItem("remainderoffset", remainderOffset);
                                           localStorage.setItem("remainderlimit", "");
                                           localStorage.setItem("remainderlimit", remainderLimit);
                                           
                                           //                                           alert("variable"+remainderOffset+""+remainderLimit);
                                           //                                           alert(localStorage.getItem("remainderoffset"));
                                           //                                           alert(localStorage.getItem("remainderlimit"));
                                           
                                           
                                           listRemainderWebService(remainderOffset, remainderLimit, localStorage.getItem("todayremainder"));
                                           $("#nextRemainder").hide();
                                           
                                           
                                           
                                           
                                           });

/*End of Functionality*/

/*Functionality call navigated to view remainder page and also remainderid and whether remainder viewed is set in here*/

function viewRemainderPage(remainderid, isviewed) {
    
    //currentActivePage = $.mobile.activePage.attr("id");
    
    $("#viewRemainderPgCloseBtn").hide();
    $("#viewRemainderPgAddCommentBtn").hide();
    
    localStorage.setItem("remainderid", remainderid);
    localStorage.setItem("remainderIsViewed", "");
    localStorage.setItem("remainderIsViewed", isviewed);
    
    changePage("#viewRemainderPg", "slide", false);
}

/*End of Functionality*/


/* Functionality for Viewing Remainder details*/

function viewRemainderDetails() {
    
    $("#addReminderCommentPageContent").hide();
    currentActivePage = $.mobile.activePage.attr("id");
    parameters = {
    reminder_id: localStorage.getItem("remainderid"),
    is_viewed: localStorage.getItem("remainderIsViewed")
    };
    
    hurdleSystemWebService("Post", "view_reminder", parameters, function(response) {
                           $("#viewRemainder").empty();
                           $("#viewRemainderComments").empty();
                           var obj = JSON.parse(response);
                           console.log(JSON.stringify(obj));
                           if (obj.msg == "Success") {
                           
                           localStorage.setItem("reminderClientNameForPushNotification","");
                           localStorage.setItem("reminderClientNameForPushNotification",obj.clientname);
                           localStorage.setItem("reminderDateForPushNotification","");
                           localStorage.setItem("reminderDateForPushNotification",obj.reminder_date);
                           
                           $("#viewRemainderPgCloseBtn").show();
                           $("#viewRemainderPgAddCommentBtn").show();
                           $("#viewRemainder").html("<li data-icon='false'>\
                                                    <div class='ui-grid-b' style='font-size:small !important;background-color:#f1f1f1;'><b>\
                                                    <div class='ui-block-a' style='width:33% !important;padding-left:2% !important;'>" + obj.type + "</div>\
                                                    <div class='ui-block-b' style='width:33% !important;white-space: nowrap !important;overflow: hidden !important;text-overflow: ellipsis;'>" + obj.clientname + "</div>\
                                                    <div class='ui-block-c' style='width:33% !important;padding-left:2% !important; text-align: right !important;'>" + obj.raised_by + "</div></b><br>\
                                                    <div class='viewHurdleDescription' style='font-size:90% !important;'><b>Description: </b>" + obj.description + "<br><b>Response: </b>" + obj.root_cause + "<br><b>Status: </b>" + obj.status + "</div></div>\
                                                    </li>");
                           
                           if (obj.status == "Closed") {
                           
                           $("#viewRemainderPgCloseBtn").addClass("borderthickness");
                           $("#viewRemainderPgAddCommentBtn").addClass("borderthickness");
                           
                           $("#viewRemainderPgCloseBtn").addClass("ui-disabled");
                           $("#viewRemainderPgAddCommentBtn").addClass("ui-disabled");
                           $("#addRemainderCommentIcon").addClass("ui-disabled");
                           
                           } else if (obj.status == "Open") {
                           
                           $("#viewRemainderPgCloseBtn").removeClass("borderthickness");
                           $("#viewRemainderPgAddCommentBtn").removeClass("borderthickness");
                           
                           $("#viewRemainderPgCloseBtn").removeClass("ui-disabled");
                           $("#viewRemainderPgAddCommentBtn").removeClass("ui-disabled");
                           $("#addRemainderCommentIcon").removeClass("ui-disabled");
                           }
                           
                           var totalReminderCommentCount = obj.comments.length;
                           for (var i = 0; i < obj.comments.length; i++) {
                           
                           if((obj.status=="Closed")&&(i== (totalReminderCommentCount-1))){
                           
                           year = obj.resolution_date.split("-")[0];
                           monthName = arry[obj.resolution_date.split("-")[1]];
                           todayDate = obj.resolution_date.split("-")[2];
                           webServiceDataConversion[i] = monthName + "-" + todayDate + "-" + year;
                           }else{
                           year = obj.comments[i].created.split("-")[0];
                           monthName = arry[obj.comments[i].created.split("-")[1]];
                           todayDate = obj.comments[i].created.split("-")[2];
                           webServiceDataConversion[i] = monthName + "-" + todayDate + "-" + year;
                           }
                           
                           if (localStorage.getItem("userId") == obj.comments[i].user_id) {
                           $("#viewRemainderComments").append("<li data-icon='false'><div style='background-color:#cbe5f8;'>\
                                                              <p class='viewHurdleDescription' style='font-size:small !important;padding-left:2px !important;'>" + obj.comments[i].description + "</p>\
                                                              <div class='ui-grid-b hurdleListFontSize'>\
                                                              <div class='ui-block-a'><p style='\
                                                              font-size:smaller !important;padding-left:2px !important;'>" + webServiceDataConversion[i] + "</p></div>\
                                                              <div class='ui-block-b' style='padding-left:5% !important;'><p style='\
                                                              font-size:smaller !important;'><b>" + obj.comments[i].username + "<b></p></div>\
                                                              <div class='ui-block-c' style='float:right !important;'><p class='viewHurdleTime' style='\
                                                              font-size:smaller !important;padding-right:2px !important;'>" + obj.comments[i].created_time + "</p><div></div></div>\
                                                              </li>");
                           $("#viewRemainderComments").listview("refresh");
                           } else {
                           $("#viewRemainderComments").append("<li data-icon='false'><div style='background-color:#f1f1f1;'>\
                                                              <p class='viewHurdleDescription'  style='\
                                                              font-size:small !important;padding-left:2px !important;'>" + obj.comments[i].description + "</p>\
                                                              <div class='ui-grid-b hurdleListFontSize'>\
                                                              <div class='ui-block-a'><p style='\
                                                              font-size:smaller !important;padding-left:2px !important;'>" + webServiceDataConversion[i] + "</p></div>\
                                                              <div class='ui-block-b' style='padding-left:5% !important;'><p style='\
                                                              font-size:smaller !important;'><b>" + obj.comments[i].username + "<b></p></div>\
                                                              <div class='ui-block-c' style='float:right !important;'><p class='viewHurdleTime' style='\
                                                              font-size:smaller !important;padding-right:2px !important;'>" + obj.comments[i].created_time + "</p></div></div></div>\
                                                              </li>");
                           
                           $("#viewRemainderComments").listview("refresh");
                           
                           }
                           }
                           hideLoadingIcon();
                           
                           /*Silent Scroll in view hurdle which go to end of page*/
                           
//                           var target1 = $.mobile.activePage.find("#viewRemainderComments li:last-child").get(0).offsetTop;
//                           $.mobile.silentScroll(target1);
                          
                           } else {
                           showAlert("Webservice Error", "Huddle System");
                           hideLoadingIcon();
                           }
                           });

}

/*End of Functionality*/


function showReminderAddCommentContents(){
    
    $("#addRemainderCommentDescription").val("");
    $("#addReminderCommentPageContent").toggle("slow");
    
}

/*Functionality for adding comment in add comment page */

function addRemainderComments() {
    if ($("#addRemainderCommentDescription").val() == " " || $("#addRemainderCommentDescription").val() == "") {
        showAlert("Please Add Description", "Huddle System");
    } else {
        parameters = {
        reminder_id: localStorage.getItem("remainderid"),
        user_id: localStorage.getItem("userId"),
        description: $("#addRemainderCommentDescription").val(),
        status: "Active",
        username: localStorage.getItem("userName"),
        clientname: localStorage.getItem("reminderClientNameForPushNotification"),
        created: localStorage.getItem("reminderDateForPushNotification")
        };
        hurdleSystemWebService("Post", "add_reminder_comments", parameters, function(response) {
                               //alert(JSON.parse(response))
                               var obj = JSON.parse(response);
                               if (obj.msg == "Success") {
                               $("#addReminderCommentPageContent").toggle("slow");
                               viewRemainderDetails();
                               changePage("#viewRemainderPg", "slide", false);
                               hideLoadingIcon();
                               } else {
                               hideLoadingIcon();
                               showAlert("Webservice Error", "Huddle System");
                               }
                               });
    }
}

/*End of Functionality*/


/*Functionality to load all select box and description of close remainder page*/

function loadClosureRemainderDetails() {
    
    $("#remainderResolutionDate").val(todayDateForSearchPage);
    $("#closureRemainderComments").val("");
    currentActivePage = $.mobile.activePage.attr("id");
    parameters = {
    reminder_id: localStorage.getItem("remainderid")
    };
    hurdleSystemWebService("Post", "view_reminder", parameters, function(response) {
                           var obj = JSON.parse(response);
//                           console.log(JSON.stringify(response));
                           if (obj.msg == "Success") {

                           $("#closureRemainderDetails").html("<li data-icon='false'>\
                                                              <div class='ui-grid-b' style='font-size:smaller !important;background-color:#f1f1f1;'><b>\
                                                              <p><div class='ui-block-a' style='width:33% !important;padding-left:2% !important;'>" + obj.type + "</div>\
                                                              <div class='ui-block-b' style='width:33% !important;white-space: nowrap !important;overflow: hidden !important;text-overflow: ellipsis;'>" + obj.clientname + "</div>\
                                                              <div class='ui-block-c' style='width:33% !important;padding-left:2% !important; text-align: right !important;'>" + obj.raised_by + "</div></p></b><br>\
                                                              <div class='viewHurdleDescription' style='font-size:90% !important;'><b>Description: </b>" + obj.description + "<br><b>Response: </b>" + obj.root_cause + "<br><b>Status: </b>" + obj.status + "</div></div>\
                                                              </li>");
                           hideLoadingIcon();
                           } else {
                           showAlert("Webservice Error", "Huddle System");
                           hideLoadingIcon();
                           }
                           });
    
}

/*End of Functionality*/


/*Validate Functionality for close hurdle page before closing*/

function validateCloseRemainderDetails() {
    
    if ($("#closureRemainderComments").val() == "" || $("#closureRemainderComments").val() == " ") {
        
        showAlert("Please Fill Description", "Close Reminder");
        
    } else if ($("#remainderResolutionDate").val() == "" || $("#remainderResolutionDate").val() == " ") {
        
        showAlert("Please Enter Resolution Date", "Close Reminder");
        
    } else {
        
        parameters = {
        reminder_id: localStorage.getItem("remainderid"),
        user_id: localStorage.getItem("userId"),
        resolution_date: $("#remainderResolutionDate").val(),
        description: $("#closureRemainderComments").val(),
        status: "Closed"
        };
        
        hurdleSystemWebService("Post", "close_reminder", parameters, function(response) {
                               var obj = JSON.parse(response);
                               //                               console.log("closehurdle"+JSON.stringify(response));
                               if (obj.msg == "Success") {
                               changePage("#viewRemainderPg", "slide", false);
                               hideLoadingIcon();
                               } else {
                               showAlert("Webservice Error", "Huddle System");
                               hideLoadingIcon();
                               }
                               });
        
        
    }
}

/*End of Functionality*/


/*Functionality to load all select box in search Remainder page*/


function loadRemainderSearchPgSelectBoxes() {
    
    $("#previousRemainder").hide();
    $("#nextRemainder").hide();
    
    $("#RemainderFromDate").val(todayDateForSearchPage);
    $("#RemainderToDate").val(todayDateForSearchPage);
    
    $("#searchRemainderStatus").html("");
    $("#searchRemainderStatus").append("<option value=''>Status</option>");
    $("#searchRemainderStatus").append("<option value='Open'>Open</option>").selectmenu("refresh");
    $("#searchRemainderStatus").append("<option value='Closed'>Closed</option>").selectmenu("refresh");
    
    
    currentActivePage = $.mobile.activePage.attr("id");
    parameters = "";
    hurdleSystemWebService("Post", "get_reminder_types", parameters, function(response) {
                           var obj = JSON.parse(response);
                           if (obj.msg == "Success") {
                           //alert(JSON.stringify(response));
                           $("#RemainderType").html("");
                           $("#RemainderType").append("<option value='remaindertype' selected>Reminder Type</option>");
                           for (var i = 0; i < obj.Reminder_types.length; i++) {
                           $("#RemainderType").append("<option value=" + obj.Reminder_types[i].id + ">" + obj.Reminder_types[i].type + "</option>").selectmenu("refresh");
                           }
                           hideLoadingIcon();
                           } else {
                           hideLoadingIcon();
                           showAlert("Webservice Error", "Huddle System");
                           }
                           });
    
    hurdleSystemWebService("Post", "get_lead", parameters, function(response) {
                           var obj = JSON.parse(response);
                           if (obj.msg == "Success") {
                           //console.log("afd"+JSON.stringify(response));
                           $("#RemainderleadName").html("");
                           $("#RemainderleadName").append("<option value='Lead Name' selected>Lead Name</option>");
                           for (var i = 0; i < obj.users.length; i++) {
                           $("#RemainderleadName").append("<option value=" + obj.users[i].id + ">" + obj.users[i].employee_actual_name + "</option>").selectmenu("refresh");
                           }
                           hideLoadingIcon();
                           } else {
                           hideLoadingIcon();
                           showAlert("Webservice Error", "Huddle System");
                           }
                           });
    
}

/*End of Functionality*/



/*Validate Functionality for search hurdle page before search*/

function validateSearchRemainderDetails() {
//    if ($("#RemainderType").val() == "remaindertype") {
//        showAlert("Please Select Reminder Type", "Search Reminder");
//        
//    } else if ($("#RemainderFromDate").val() == "" || $("#RemainderFromDate").val() == " ") {
//        showAlert("Please Enter From Date", "Search Reminder");
//        
//    } else if ($("#RemainderToDate").val() == "" || $("#RemainderToDate").val() == " ") {
//        showAlert("Please Enter To Date", "Search Reminder");
//        
//        
//    } else if ($("#RemainderleadName").val() == "Lead Name") {
//        showAlert("Please Select Lead Name", "Search Reminder");
//        
//        
//    } else if ($("#searchRemainderStatus").val() == "Status") {
//        showAlert("Please Select Reminder Status", "Search Reminder");
//        
//    } else {
    
        changePage("#filterRemainderPg", "slide", false);
        
//    }
    
}
/*End of Functionality*/

/* Functionality to reset search hurdle form*/

function resetRemainderSearchForm() {
    
    $("#searchRemainderForm").trigger("reset");
    
}

/*End of Functionality*/


/* To hide pagination button at top and bottom when moving back from viewhurdle page */
function fromViewRemainderPg() {
    
    localStorage.setItem("todayremainder","0");
    $("#previousRemainder").hide();
    $("#nextRemainder").hide();
    
}
/*End of Functionality*/


function backFromRemainderSearch() {
    
    currentActivePage = "filterRemainderPg";
    changePage("#filterRemainderPg", "slide", true);
    
}



